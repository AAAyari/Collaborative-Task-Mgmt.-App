document.addEventListener("DOMContentLoaded", () => {
  const createProjectBtn = document.getElementById("create-project-btn");
  const tasksBtn = document.getElementById("tasks-btn");
  const reportBtn = document.getElementById("report-btn");
  const createTaskBtn = document.getElementById("create-task-btn");
  const backToCreateBtn = document.getElementById("back-to-create-btn");
  const navHomeBtn = document.getElementById("nav-home-btn");
  const saveTaskBtn = document.getElementById("save-task-btn");
  
  function navigateTo(pageId) {
    const pages = document.querySelectorAll(".page");
    pages.forEach(page => {
      page.style.display = "none";
    });
    document.getElementById(pageId).style.display = "block";
  }

  createProjectBtn.addEventListener("click", () => {
    navigateTo('create-project-page');
  });

  tasksBtn.addEventListener("click", () => {
    navigateTo('tasks-page');
  });

  reportBtn.addEventListener("click", () => {
    alert("Report Generation feature is not implemented yet.");
  });

  createTaskBtn.addEventListener("click", () => {
    navigateTo('create-task-page');
  });

  backToCreateBtn.addEventListener("click", () => {
    navigateTo('create-project-page');
  });

  navHomeBtn.addEventListener("click", () => {
    navigateTo('home-page');
  });

  saveTaskBtn.addEventListener("click", () => {
    navigateTo('tasks-page');
  });
});