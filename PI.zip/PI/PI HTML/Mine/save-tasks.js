// Elements
const tasksPage = document.getElementById("tasks-page");
const createTaskPage = document.getElementById("create-task-page");
const createTaskBtn = document.getElementById("create-task-btn");
const saveTaskBtn = document.getElementById("save-task-btn");
const tasksTableBody = document.getElementById("tasks-table-body");
const noTasksMessage = document.getElementById("no-tasks-message");
const tasksTable = document.getElementById("tasks-table");

let tasks = [];

// Show the task creation form
createTaskBtn.addEventListener("click", () => {
  tasksPage.classList.add("hidden");
  createTaskPage.classList.remove("hidden");
});

// Save a new task
saveTaskBtn.addEventListener("click", () => {
  const projectName = document.getElementById("task-project").value;
  const taskName = document.getElementById("task-name").value;
  const taskManager = document.getElementById("task-manager").value;
  const assignedTo = document.getElementById("task-team").value;
  const dueDate = document.getElementById("task-due-date").value;

  // Validate inputs
  if (!projectName || !taskName || !taskManager || !assignedTo || !dueDate) {
    alert("Please fill out all fields!");
    return;
  }

  // Save task
  tasks.push({ projectName, taskName, taskManager, assignedTo, dueDate });

  // Update task table
  updateTasksTable();

  // Switch back to tasks page
  createTaskPage.classList.add("hidden");
  tasksPage.classList.remove("hidden");
});

// Update the tasks table
function updateTasksTable() {
  if (tasks.length === 0) {
    noTasksMessage.classList.remove("hidden");
    tasksTable.classList.add("hidden");
  } else {
    noTasksMessage.classList.add("hidden");
    tasksTable.classList.remove("hidden");

    tasksTableBody.innerHTML = ""; // Clear existing rows
    tasks.forEach((task) => {
      const row = `
        <tr>
          <td>${task.projectName}</td>
		  <td>${task.taskName}</td>
		  <td>${task.taskManager}</td>
          <td>${task.assignedTo}</td>
          <td>${task.dueDate}</td>
        </tr>
      `;
      tasksTableBody.innerHTML += row;
    });
  }
}

//delete tasks
function deleteItem() {
  const inputField = document.querySelector('.input-box');
  if (!inputField || inputField.value.trim() === "") {
      alert("Please select the parameters to delete !");
      return;
  }
  const confirmed = confirm("Are you sure you want to delete this task?");
  if (confirmed) {
      alert("Task deleted successfully!");
      window.location.href = "track-tasks.html"; 
  }
}

function saveChanges() {
  alert("Changes saved !");
  window.location.href = "project-management.html"; 
}