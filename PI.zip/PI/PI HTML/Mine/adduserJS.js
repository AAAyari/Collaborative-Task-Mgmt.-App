function validateForm() {
    var username = document.getElementById("username").value.trim();
    var email = document.getElementById("email").value.trim();

    if (!/^[A-Za-z\s]+$/.test(username) || username.split(" ").length < 2) {
    alert("Please enter your full name with only letters and at least two words separated by a space.");
    return false;
}

    if (!email.includes("@") || !email.includes(".") || email.lastIndexOf(".") < email.indexOf("@")) {
        alert("Please enter a valid email address (e.g., name@example.com).");
        return false; // hedhi lezem yaani l lastIndexof l point ykoun baad l @
					  // akeka net2akdou li fama @domainName.domainExtension
    }

    alert("Form submitted successfully!\n" +
          "User Name: " + username + "\n" +
          "Email: " + email);

    return true;
}
