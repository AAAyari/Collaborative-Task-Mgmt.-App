// Elements
const createProjectPage = document.getElementById("create-project-page");
const tasksPage = document.getElementById("tasks-page");
const createTaskPage = document.getElementById("create-task-page");
const createProjectBtn = document.getElementById("create-project-btn");
const createTaskBtn = document.getElementById("create-task-btn");
const saveTaskBtn = document.getElementById("save-task-btn");
const backToCreateBtn = document.getElementById("back-to-create-btn");
const tasksTableBody = document.getElementById("tasks-table-body");
const noTasksMessage = document.getElementById("no-tasks-message");
const tasksTable = document.getElementById("tasks-table");

let tasks = [];

// Validate form inputs
function validateForm(formInputs) {
  let isValid = true;
  formInputs.forEach((input) => {
    if (!input.value.trim()) {
      isValid = false;
      input.classList.add("error"); // Add error styling
    } else {
      input.classList.remove("error"); // Remove error styling
    }
  });
  return isValid;
}

// Create a project
createProjectBtn.addEventListener("click", () => {
  const projectInputs = [
    document.getElementById("project-name"),
    document.getElementById("team-name"),
    document.getElementById("person-in-charge"),
    document.getElementById("due-date"),
  ];

  if (!validateForm(projectInputs)) {
    alert("Please fill out all fields!");
    return;
  }

  createProjectPage.classList.add("hidden");
  tasksPage.classList.remove("hidden");
});

// Show the create task form
createTaskBtn.addEventListener("click", () => {
  tasksPage.classList.add("hidden");
  createTaskPage.classList.remove("hidden");
});

// Save a new task
saveTaskBtn.addEventListener("click", () => {
  const taskInputs = [
    document.getElementById("task-project-name"),
    document.getElementById("task-name"),
    document.getElementById("task-manager"),
    document.getElementById("task-team"),
    document.getElementById("task-members"),
    document.getElementById("task-due-date"),
  ];

  if (!validateForm(taskInputs)) {
    alert("Please fill out all fields!");
    return;
  }

  const projectName = document.getElementById("task-project-name").value;
  const taskName = document.getElementById("task-name").value;
  const manager = document.getElementById("task-manager").value;
  const team = document.getElementById("task-team").value;
  const members = document.getElementById("task-members").value;
  const dueDate = document.getElementById("task-due-date").value;

  tasks.push({ projectName, taskName, manager, team, members, dueDate });

  updateTasksTable();
  createTaskPage.classList.add("hidden");
  tasksPage.classList.remove("hidden");
});

// Update the tasks table
function updateTasksTable() {
  if (tasks.length === 0) {
    noTasksMessage.classList.remove("hidden");
    tasksTable.classList.add("hidden");
  } else {
    noTasksMessage.classList.add("hidden");
    tasksTable.classList.remove("hidden");

    tasksTableBody.innerHTML = "";
    tasks.forEach((task) => {
      const row = `
        <tr>
          <td>${task.projectName}</td>
          <td>${task.taskName}</td>
          <td>${task.manager}</td>
          <td>${task.team}</td>
          <td>${task.members}</td>
          <td>${task.dueDate}</td>
        </tr>
      `;
      tasksTableBody.innerHTML += row;
    });
  }
}

// Back to Create Project
backToCreateBtn.addEventListener("click", () => {
  tasksPage.classList.add("hidden");
  createProjectPage.classList.remove("hidden");
});

function navigateTo(pageId) {
  // Hide all pages
  const pages = document.querySelectorAll('.page');
  for (let i = 0; i < pages.length; i++) {
    pages[i].classList.add('hidden');
  }

  // Show the target page
  const targetPage = document.getElementById(pageId);
  if (targetPage) {
    targetPage.classList.remove('hidden');
  } else {
    console.error(`Page with ID "${pageId}" not found.`);
  }
}






