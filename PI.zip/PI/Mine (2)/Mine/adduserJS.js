function validateForm() {
    var username = document.getElementById("username").value.trim();
    var email = document.getElementById("email").value.trim();

    if (!/^[A-Za-z\s]+$/.test(username) || username.split(" ").length < 2) {
    alert("Please enter your full name with only letters and at least two words separated by a space.");
    return false;
}

    if (!email.includes("@") || !email.includes(".") || email.lastIndexOf(".") < email.indexOf("@")) {
        alert("Please enter a valid email address (e.g., name@example.com).");
        return false; // hedhi lezem yaani l lastIndexof l point ykoun baad l @
					  // akeka net2akdou li fama @domainName.domainExtension
    }

    alert("Form submitted successfully!\n" +
          "User Name: " + username + "\n" +
          "Email: " + email);

    return true;
}

const projectsTable = document.getElementById("projects-table");
const projectsTableBody = document.getElementById("projects-table-body");
const noProjectsMessage = document.getElementById("no-projects-message");

// Array to store project data
let projects = JSON.parse(localStorage.getItem("projects")) || [];

// Function to update the projects table
function updateProjectsTable() {
    if (projects.length === 0) {
        // Show "no projects added" message if the array is empty
        noProjectsMessage.classList.remove("hidden");
        projectsTable.classList.add("hidden");
    } else {
        // Hide the message and display the table
        noProjectsMessage.classList.add("hidden");
        projectsTable.classList.remove("hidden");

        // Clear the table body and populate it with project data
        projectsTableBody.innerHTML = "";
        projects.forEach((project) => {
            const row = `
                <tr>
                    <td>${project.name}</td>
                    <td>${project.manager}</td>
                    <td>${project.team}</td>
                    <td>${project.dueDate}</td>
                    <td><span class="status-${project.status.toLowerCase()}">${project.status}</span></td>
                </tr>
            `;
            projectsTableBody.innerHTML += row;
        });
    }
}

// Example: Adding projects manually (you can replace this with data from localStorage or another source)
projects = [
    { name: "Project Phoenix", manager: "John Doe", team: "Development Team", dueDate: "2025-04-15", status: "New" },
    { name: "Project Orion", manager: "Jane Smith", team: "Marketing Team", dueDate: "2025-05-01", status: "In Progress" },
    { name: "Project Apollo", manager: "Michael Brown", team: "Design Team", dueDate: "2025-06-20", status: "Completed" }
];

// Save to localStorage for persistence (if needed)
localStorage.setItem("projects", JSON.stringify(projects));

// Call the update function on page load
updateProjectsTable();

