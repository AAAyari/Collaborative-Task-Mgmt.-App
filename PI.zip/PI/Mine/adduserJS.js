// function validateForm() {
//     var username = document.getElementById("username").value.trim();
//     var email = document.getElementById("email").value.trim();

//     if (!/^[A-Za-z\s]+$/.test(username) || username.split(" ").length < 2) {
//     alert("Please enter your full name with only letters and at least two words separated by a space.");
//     return false;
//     }

//     if (!email.includes("@") || !email.includes(".") || email.lastIndexOf(".") < email.indexOf("@")) {
//         alert("Please enter a valid email address (e.g., name@example.com).");
//         return false; // hedhi lezem yaani l lastIndexof l point ykoun baad l @
// 					  // akeka net2akdou li fama @domainName.domainExtension
//     }

//     alert("Form submitted successfully!\n" +
//           "User Name: " + username + "\n" +
//           "Email: " + email);

//     return true;
// }

function validateForm() {
    // Get input fields
    var username = document.getElementById("username");
    var email = document.getElementById("email");

    // Clear previous error styles and messages
    clearError(username);
    clearError(email);

    var isValid = true;

    // Validate username
    var usernameValue = username.value.trim();
    if (!/^[A-Za-z\s]+$/.test(usernameValue) || usernameValue.split(" ").length < 2) {
        setError(username, "Please enter your full name with only letters and at least two words separated by a space.");
        isValid = false;
    }

    // Validate email
    var emailValue = email.value.trim();
    if (!emailValue.includes("@") || !emailValue.includes(".") || emailValue.lastIndexOf(".") < emailValue.indexOf("@")) {
        setError(email, "Please enter a valid email address (e.g., name@example.com).");
        isValid = false;
    }

    return isValid;
}

// Function to set error styles and tooltip
function setError(element, message) {
    // Add error style to the input field
    element.style.border = "2px solid red";

    // Check if an error message already exists
    let errorContainer = element.nextElementSibling;
    if (!errorContainer || !errorContainer.classList.contains('error-message')) {
        // Create a span element for the error message
        errorContainer = document.createElement('span');
        errorContainer.classList.add('error-message');
        element.parentNode.insertBefore(errorContainer, element.nextSibling);
    }

    // Set the error message
    errorContainer.textContent = message;
}




// Function to clear error styles and messages
function clearError(element) {
    // Reset the input field style
    element.style.border = "";

    // Remove the error message if it exists
    let errorContainer = element.nextElementSibling;
    if (errorContainer && errorContainer.classList.contains('error-message')) {
        errorContainer.remove();
    }
}
// Example of redirecting after processing
if (userAddedSuccessfully) {
window.location.href = "view-users.html?message=User added successfully!";
} else {
window.location.href = "view-users.html?message=Error adding user.";
}

//contol access
function saveChanges() {
    alert("Changes saved !");
    window.location.href = "users-management.html"; 
}

//delete user
function deleteItem() {
    const inputField = document.querySelector('.input-box');
    if (!inputField || inputField.value.trim() === "") {
        alert("Please select a username to delete !");
        return;
    }
    const confirmed = confirm("Are you sure you want to delete this user ?");
    if (confirmed) {
        alert("User deleted !");
        window.location.href = "view-users.html"; 
    }
}