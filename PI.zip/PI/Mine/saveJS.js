
// Function to save a new task
function saveTask() {
    console.log('saveTask function called'); // Debug log
    
    // Get input values
    const task = {
        project: document.getElementById('task-project').value,
        name: document.getElementById('task-name').value,
        manager: document.getElementById('task-manager').value,
        team: document.getElementById('task-team').value,
        dueDate: document.getElementById('task-due-date').value
    };
    
    console.log('New task:', task); // Debug log
    
    // Get existing tasks from localStorage or initialize empty array
    let tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    console.log('Existing tasks:', tasks); // Debug log
    
    // Add new task to array
    tasks.push(task);
    
    // Save updated tasks array to localStorage
    localStorage.setItem('tasks', JSON.stringify(tasks));
    console.log('Tasks after saving:', JSON.parse(localStorage.getItem('tasks'))); // Debug log
    
    // Clear form
    document.getElementById('task-form').reset();
    
    // Show success message
    alert('Task saved successfully!');
    
    // Redirect to update tasks page
    window.location.href = 'update-tasks.html';
}

// Function to display tasks in the table
function displayTasks() {
    console.log('displayTasks function called'); // Debug log
    
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    console.log('Tasks retrieved for display:', tasks); // Debug log
    
    const tbody = document.querySelector('#tasks-table tbody');
    if (!tbody) {
        console.error('Could not find tbody element!'); // Debug log
        return;
    }
    
    // Clear existing rows
    tbody.innerHTML = '';
    
    // Add each task to the table
    tasks.forEach((task, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${task.name}</td>
            <td>${task.project}</td>
            <td>${task.team}</td>
            <td>${task.dueDate}</td>
            <td><button class="btn" onclick="editTask(${index})">Edit</button></td>
        `;
        tbody.appendChild(row);
    });
    
    console.log('Table updated with', tasks.length, 'tasks'); // Debug log
}

// Function to edit a task
function editTask(index) {
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    const task = tasks[index];
    alert(`
        Task Name: ${task.name}
        Project: ${task.project}
        Manager: ${task.manager}
        Team: ${task.team}
        Due Date: ${task.dueDate}
    `);
}

// Add this line to make sure displayTasks runs when the update page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', displayTasks);
} else {
    displayTasks();
}









// saveProject.js

// Function to save a new project
function saveProject(event) {
    event.preventDefault(); // Prevent form from refreshing the page

    console.log('saveProject function called'); // Debug log

    // Get input values
    const project = {
        title: document.getElementById('project-title').value,
        team: document.getElementById('team').value,
        manager: document.getElementById('project-manager').value,
        dueDate: document.getElementById('project-due-date').value
    };

    console.log('New project:', project); // Debug log

    // Get existing projects from localStorage or initialize empty array
    let projects = JSON.parse(localStorage.getItem('projects') || '[]');
    console.log('Existing projects:', projects); // Debug log

    // Add new project to array
    projects.push(project);

    // Save updated projects array to localStorage
    localStorage.setItem('projects', JSON.stringify(projects));
    console.log('Projects after saving:', JSON.parse(localStorage.getItem('projects'))); // Debug log

    // Clear form
    document.getElementById('project-form').reset();

    // Show success message
    alert('Project created successfully!');

    // Redirect to update projects page
    window.location.href = 'update-project.html';
}

// Function to display projects in the table
function displayProjects() {
    console.log('displayProjects function called'); // Debug log

    const projects = JSON.parse(localStorage.getItem('projects') || '[]');
    console.log('Projects retrieved for display:', projects); // Debug log

    const tbody = document.querySelector('#projects-table tbody');
    if (!tbody) {
        console.error('Could not find tbody element!'); // Debug log
        return;
    }

    // Clear existing rows
    tbody.innerHTML = '';

    // Add each project to the table
    projects.forEach((project, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${project.title}</td>
            <td>${project.team}</td>
            <td>${project.manager}</td>
            <td>${project.dueDate}</td>
            <td><button class="btn" onclick="editProject(${index})">Edit</button></td>
        `;
        tbody.appendChild(row);
    });

    console.log('Table updated with', projects.length, 'projects'); // Debug log
}

// Function to edit a project
function editProject(index) {
    const projects = JSON.parse(localStorage.getItem('projects') || '[]');
    const project = projects[index];
    alert(`
        Project Title: ${project.title}
        Team: ${project.team}
        Manager: ${project.manager}
        Due Date: ${project.dueDate}
    `);
}

// Add this line to make sure displayProjects runs when the update page loads
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', displayProjects);
} else {
    displayProjects();
}

// Attach the saveProject function to the form submission
const projectForm = document.getElementById('project-form');
if (projectForm) {
    projectForm.addEventListener('submit', saveProject);
}
